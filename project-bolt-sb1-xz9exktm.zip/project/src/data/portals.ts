export interface PortalLink {
  label: string;
  url: string;
}

export interface VisaCountry {
  country: string;
  flag: string;
  links: PortalLink[];
}

export interface NamedLink {
  name: string;
  url: string;
}

export interface WebsiteCard {
  title: string;
  dataTitle: string;
  url: string;
  image: string;
  alt: string;
  artLabel: string;
  description: string;
  openLabel: string;
}

export const websiteCards: WebsiteCard[] = [
  {
    title: 'Europe Visa Guide',
    dataTitle: 'europe visa guide',
    url: 'https://hassanaliuk11-oss.github.io/europevisa/',
    image: 'https://res.cloudinary.com/bppt4zlw/image/upload/f_auto/q_auto/work_visa_1.webp',
    alt: 'Work visa opportunities',
    artLabel: 'Europe Visa Guide',
    description: 'European visa and application information',
    openLabel: 'Open website ↗',
  },
  {
    title: 'Professional CV & Document Center',
    dataTitle: 'professional cv document center europass',
    url: 'https://professional-cv-document-center.vercel.app/',
    image: 'https://images.unsplash.com/photo-1586281380349-632531db7ed4?q=80&w=800&auto=format&fit=crop',
    alt: 'CV and document services',
    artLabel: 'CV & Documents',
    description: 'CV, resume, Europass and document-writing services',
    openLabel: 'Hire me ↗',
  },
  {
    title: 'USA / American Countries',
    dataTitle: 'usa american countries opportunities',
    url: 'https://hassanaliuk11-oss.github.io/American-USA-/',
    image: 'https://images.unsplash.com/photo-1508433957232-3107f5fd5995?q=80&w=800&auto=format&fit=crop',
    alt: 'USA Opportunities',
    artLabel: 'USA Opportunities',
    description: 'Explore USA-related application resources',
    openLabel: 'Open website ↗',
  },
  {
    title: 'Asian Countries',
    dataTitle: 'asian countries pakistan apply',
    url: 'https://hassanaliuk11-oss.github.io/Asian-country-apply-from-Pakistan-/',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=800&auto=format&fit=crop',
    alt: 'Asia Opportunities',
    artLabel: 'Asia Opportunities',
    description: 'Country application resources from Pakistan',
    openLabel: 'Open website ↗',
  },
  {
    title: 'European Countries & Jobs',
    dataTitle: 'jobs in europe european countries',
    url: 'https://hassanaliuk11-oss.github.io/Jobsineurope/',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=800&auto=format&fit=crop',
    alt: 'Work visa and jobs in Europe',
    artLabel: 'Jobs in Europe',
    description: 'European job-search information and resources',
    openLabel: 'Open website ↗',
  },
  {
    title: 'University Scholarships',
    dataTitle: 'university scholarships study abroad',
    url: 'https://hassanaliuk11-oss.github.io/Www-apply-for-Europe-/',
    image: 'https://res.cloudinary.com/bppt4zlw/image/upload/f_auto/q_auto/college_admittion.webp',
    alt: 'College admission and university scholarships',
    artLabel: 'Scholarships',
    description: 'Scholarship and study-abroad resources',
    openLabel: 'Open website ↗',
  },
  {
    title: 'EU / European Union',
    dataTitle: 'eu european union',
    url: 'https://hassanaliuk11-oss.github.io/EUROPE/',
    image: 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?q=80&w=800&auto=format&fit=crop',
    alt: 'European Union',
    artLabel: 'European Union',
    description: 'European Union country information and resources',
    openLabel: 'Open website ↗',
  },
  {
    title: 'MAECI Scholarship — Italy',
    dataTitle: 'italy government maeci scholarship',
    url: 'https://studyinitaly.esteri.it/',
    image: 'https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?auto=format&fit=crop&w=800&q=75',
    alt: 'Italy Government MAECI Scholarship',
    artLabel: 'Italy Government Scholarships',
    description: 'Explore Italian government scholarships for eligible international students pursuing higher education in Italy.',
    openLabel: 'Official Portal ↗',
  },
  {
    title: 'Invest Your Talent in Italy (IYT)',
    dataTitle: 'invest your talent in italy scholarship',
    url: 'https://investyourtalentapplication.esteri.it/',
    image: 'https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=800&q=75',
    alt: 'Invest Your Talent in Italy Scholarship',
    artLabel: 'Study & Internship',
    description: 'Explore eligible master\u2019s programs, scholarship opportunities and industry internship pathways in Italy.',
    openLabel: 'Apply Online ↗',
  },
  {
    title: 'Lombardy Regional Scholarships',
    dataTitle: 'lombardy region university milan dsu scholarship',
    url: 'https://www.unimi.it/en/study/financial-support/regional-scholarships',
    image: 'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?auto=format&fit=crop&w=800&q=75',
    alt: 'Lombardy Milan Regional Scholarship',
    artLabel: 'Lombardy Region',
    description: 'Find regional financial support information for eligible university students in Lombardy, including Milan.',
    openLabel: 'Scholarship Details ↗',
  },
  {
    title: 'DSU Toscana Scholarship',
    dataTitle: 'tuscany dsu scholarship pisa florence siena',
    url: 'https://www.dsu.toscana.it/',
    image: 'https://images.unsplash.com/photo-1513584684374-8bab748fbf90?auto=format&fit=crop&w=800&q=75',
    alt: 'Tuscany DSU Regional Scholarship',
    artLabel: 'Tuscany Region',
    description: 'Explore regional student financial aid opportunities for eligible students in Tuscany, including Pisa, Florence and Siena.',
    openLabel: 'Official Website ↗',
  },
  {
    title: 'DAAD Scholarship Database',
    dataTitle: 'germany daad scholarship database',
    url: 'https://www.daad.de/stipdb-redirect/',
    image: 'https://images.unsplash.com/photo-1467269204594-9661b134dd2b?auto=format&fit=crop&w=800&q=75',
    alt: 'Germany DAAD Scholarships',
    artLabel: 'Germany Scholarships',
    description: 'Search scholarships and funding opportunities for international students interested in studying in Germany.',
    openLabel: 'Find Scholarships ↗',
  },
  {
    title: 'DAAD My GUIDE',
    dataTitle: 'daad my guide germany university course finder',
    url: 'https://www.myguide.de/en/',
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=800&q=75',
    alt: 'Germany University Course Finder',
    artLabel: 'Course & University Finder',
    description: 'Explore suitable degree programmes and universities in Germany based on your educational background.',
    openLabel: 'Find Your Course ↗',
  },
  {
    title: 'Uni-assist Germany',
    dataTitle: 'uni assist germany university applications',
    url: 'https://www.uni-assist.de/',
    image: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&w=800&q=75',
    alt: 'Uni Assist Germany University Admissions',
    artLabel: 'University Admissions',
    description: 'Learn about international student applications and check whether your chosen university uses uni-assist.',
    openLabel: 'Apply & Explore ↗',
  },
  {
    title: 'Deutschlandstipendium',
    dataTitle: 'deutschlandstipendium official scholarship',
    url: 'https://www.deutschlandstipendium.de/',
    image: 'https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?auto=format&fit=crop&w=800&q=75',
    alt: 'Deutschlandstipendium Scholarship Germany',
    artLabel: 'Merit-Based Scholarship',
    description: 'Explore Germany\u2019s merit-based scholarship programme and its eligibility requirements.',
    openLabel: 'Official Website ↗',
  },
  {
    title: 'Erasmus Mundus Joint Masters',
    dataTitle: 'erasmus mundus joint masters scholarships europe',
    url: 'https://erasmus-plus.ec.europa.eu/opportunities/opportunities-for-individuals/students/erasmus-mundus-joint-masters',
    image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=800&q=75',
    alt: 'Erasmus Mundus Joint Masters Europe',
    artLabel: 'Erasmus Mundus',
    description: 'Discover joint master\u2019s programmes across European universities and check available scholarship funding.',
    openLabel: 'Explore Programs ↗',
  },
  {
    title: 'European Union Study Portal',
    dataTitle: 'official european union study in europe portal',
    url: 'https://education.ec.europa.eu/study-in-europe',
    image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=800&q=75',
    alt: 'Study in Europe Universities and Scholarships',
    artLabel: 'Study in Europe',
    description: 'Explore study destinations, universities and education information across Europe.',
    openLabel: 'Explore Europe ↗',
  },
  {
    title: 'Campus France',
    dataTitle: 'france campus france scholarships international students',
    url: 'https://www.campusfrance.org/',
    image: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=75',
    alt: 'France Campus France Scholarships',
    artLabel: 'France Scholarships',
    description: 'Find information about studying in France, universities, scholarships and student services.',
    openLabel: 'Explore France ↗',
  },
  {
    title: 'Stipendium Hungaricum',
    dataTitle: 'hungary stipendium hungaricum scholarship',
    url: 'https://stipendiumhungaricum.hu/',
    image: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=800&q=75',
    alt: 'Hungary Stipendium Hungaricum Scholarship',
    artLabel: 'Hungary Scholarships',
    description: 'Explore Hungary\u2019s international scholarship programme, available study fields and application requirements.',
    openLabel: 'Official Scholarship ↗',
  },
  {
    title: 'Study in NL',
    dataTitle: 'netherlands study in nl university scholarships',
    url: 'https://www.studyinnl.org/',
    image: 'https://images.unsplash.com/photo-1512470876302-972faa2aa9a4?auto=format&fit=crop&w=800&q=75',
    alt: 'Study in Netherlands Universities',
    artLabel: 'Study in Netherlands',
    description: 'Explore Dutch universities, English-taught programmes and scholarship information for international students.',
    openLabel: 'Explore Netherlands ↗',
  },
  {
    title: 'University Admissions Sweden',
    dataTitle: 'sweden university admissions official portal',
    url: 'https://www.universityadmissions.se/',
    image: 'https://images.unsplash.com/photo-1509356843151-3e7d96241e11?auto=format&fit=crop&w=800&q=75',
    alt: 'Sweden University Admissions',
    artLabel: 'Study in Sweden',
    description: 'Search Swedish university programmes and find information about international admissions and application requirements.',
    openLabel: 'Apply for Admission ↗',
  },
  {
    title: 'Study in Flanders — Belgium',
    dataTitle: 'belgium study in flanders master mind scholarships',
    url: 'https://www.studyinflanders.be/',
    image: 'https://images.unsplash.com/photo-1491557345352-5929e343eb89?auto=format&fit=crop&w=800&q=75',
    alt: 'Belgium Study in Flanders Scholarships',
    artLabel: 'Belgium Scholarships',
    description: 'Explore universities, international study programmes and information about scholarships in Flanders.',
    openLabel: 'Explore Belgium ↗',
  },
  {
    title: 'DiSCo Lazio Scholarship',
    dataTitle: 'lazio disco regional scholarship rome',
    url: 'https://www.laziodisco.it/',
    image: 'https://images.unsplash.com/photo-1529260830199-42c24126f198?auto=format&fit=crop&w=800&q=75',
    alt: 'Lazio DiSCo Scholarship Rome',
    artLabel: 'Lazio Region',
    description: 'Discover regional student support and scholarship information for eligible university students in Rome and Lazio.',
    openLabel: 'Official Portal ↗',
  },
  {
    title: 'ER.GO Emilia Romagna Scholarship',
    dataTitle: 'emilia romagna ergo regional scholarship bologna',
    url: 'https://www.er-go.it/',
    image: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=75',
    alt: 'Emilia Romagna Ergo Regional Scholarship',
    artLabel: 'Emilia Romagna',
    description: 'Explore regional student financial aid opportunities for eligible students in Emilia Romagna, including Bologna.',
    openLabel: 'Official Website ↗',
  },
  {
    title: 'Fulbright Foreign Student Program',
    dataTitle: 'fulbright foreign student program scholarship',
    url: 'https://foreign.fulbrightonline.org/',
    image: 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=800&q=75',
    alt: 'Fulbright Foreign Student Scholarship Program',
    artLabel: 'Fulbright Scholarship',
    description: 'Explore international study opportunities through the Fulbright Foreign Student Program.',
    openLabel: 'Visit Official Portal ↗',
  },
  {
    title: 'HEC US-Pakistan Knowledge Corridor',
    dataTitle: 'hec us pakistan knowledge corridor scholarship',
    url: 'https://www.hec.gov.pk/english/scholarshipsgrants/US-Pakcorridor/Pages/default.aspx',
    image: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=75',
    alt: 'HEC US Pakistan Knowledge Corridor',
    artLabel: 'HEC Scholarships',
    description: 'Explore scholarship opportunities and official HEC information for studying in the United States.',
    openLabel: 'Visit Official HEC Portal ↗',
  },
  {
    title: 'Knight-Hennessy Scholars — Stanford',
    dataTitle: 'knight hennessy scholars stanford university',
    url: 'https://knight-hennessy.stanford.edu/',
    image: 'https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?auto=format&fit=crop&w=800&q=75',
    alt: 'Stanford University Knight Hennessy Scholars',
    artLabel: 'Stanford Scholars',
    description: 'Explore the Knight-Hennessy Scholars program at Stanford University for graduate-level funding.',
    openLabel: 'Explore Stanford ↗',
  },
  {
    title: 'Scholarships & Colleges',
    dataTitle: 'scholarships and colleges',
    url: 'https://english-online-seven.vercel.app/',
    image: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=800&q=75',
    alt: 'Scholarships and Colleges',
    artLabel: 'Scholarships & Colleges',
    description: 'Explore Colleges, International Scholarships and Study Opportunities Abroad.',
    openLabel: 'Explore Now ↗',
  },
  {
    title: 'Global Government Jobs Directory',
    dataTitle: 'global government jobs directory',
    url: 'https://jobdirectly.com/governmentjobs',
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=75',
    alt: 'Global Government Jobs Directory',
    artLabel: 'Government Jobs Worldwide',
    description: 'Explore government job directories and recruitment portal links for different countries around the world.',
    openLabel: 'Explore Government Jobs ↗',
  },
  {
    title: 'Government Job Commissions Directory',
    dataTitle: 'worldwide public service commissions government jobs',
    url: 'https://opporise.vercel.app/government-jobs',
    image: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=800&q=75',
    alt: 'Public Service Commissions and Government Recruitment',
    artLabel: 'Public Service Commissions',
    description: 'Explore public service commissions and government recruitment resources in different countries.',
    openLabel: 'View Directory ↗',
  },
  {
    title: 'Jobseeker Global Career Platform',
    dataTitle: 'jobseeker global jobs and career platform',
    url: 'https://www.jobseeker.com/en/about-us',
    image: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=800&q=75',
    alt: 'Global Job Search and Career Opportunities',
    artLabel: 'Global Career Network',
    description: 'Explore career resources, resume tools and job-search information for international opportunities.',
    openLabel: 'Explore Careers ↗',
  },
  {
    title: 'Indeed Worldwide Jobs',
    dataTitle: 'indeed worldwide international job search',
    url: 'https://www.indeed.com/worldwide',
    image: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=75',
    alt: 'Indeed Worldwide Job Search',
    artLabel: 'Worldwide Job Search',
    description: 'Access Indeed\u2019s country-specific job-search websites and explore international employment opportunities.',
    openLabel: 'Find Jobs Worldwide ↗',
  },
  {
    title: 'EURES — European Job Mobility Portal',
    dataTitle: 'eures official european jobs mobility portal',
    url: 'https://europa.eu/eures/portal/',
    image: 'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?auto=format&fit=crop&w=800&q=75',
    alt: 'European Jobs and Career Opportunities',
    artLabel: 'European Jobs Portal',
    description: 'Explore job vacancies, career information and employment mobility resources across European countries.',
    openLabel: 'Search European Jobs ↗',
  },
  {
    title: 'United Nations Careers',
    dataTitle: 'united nations international careers jobs',
    url: 'https://careers.un.org/',
    image: 'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?auto=format&fit=crop&w=800&q=75',
    alt: 'United Nations International Careers',
    artLabel: 'United Nations Careers',
    description: 'Explore career opportunities and vacancies with the United Nations and its international offices.',
    openLabel: 'Official UN Careers ↗',
  },
  {
    title: 'ReliefWeb International Jobs',
    dataTitle: 'reliefweb international humanitarian ngo jobs',
    url: 'https://reliefweb.int/jobs',
    image: 'https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?auto=format&fit=crop&w=800&q=75',
    alt: 'International Humanitarian and NGO Jobs',
    artLabel: 'International NGO Jobs',
    description: 'Discover humanitarian, emergency response and international development job opportunities around the world.',
    openLabel: 'Explore NGO Jobs ↗',
  },
  {
    title: 'Apply for Europe',
    dataTitle: 'apply for europe guidance',
    url: 'https://hassanaliuk11-oss.github.io/Apllyforeurope/',
    image: 'https://res.cloudinary.com/bppt4zlw/image/upload/f_auto/q_auto/file_00000000d7c88211ac190b2df7c03056.png',
    alt: 'Apply for Europe opportunities',
    artLabel: 'Apply for Europe',
    description: 'Explore European application links and guidance',
    openLabel: 'Open website ↗',
  },
  {
    title: 'LinkedIn Jobs Europe',
    dataTitle: 'linkedin jobs europe professional networking',
    url: 'https://www.linkedin.com/jobs/search/?location=Europe',
    image: 'https://images.unsplash.com/photo-1572044162444-ad60e140b9c5?q=80&w=800&auto=format&fit=crop',
    alt: 'LinkedIn Jobs Europe',
    artLabel: 'LinkedIn Europe Jobs',
    description: 'Search professional jobs across all European countries on LinkedIn — the world\'s largest professional network.',
    openLabel: 'Search LinkedIn Jobs ↗',
  },
  {
    title: 'Remote Europe Jobs',
    dataTitle: 'remote europe jobs work from home online apply',
    url: 'https://remoteok.com/remote-europe-jobs',
    image: 'https://images.unsplash.com/photo-1521737711867-e3b97375f902?q=80&w=800&auto=format&fit=crop',
    alt: 'Remote Europe Jobs Work From Home',
    artLabel: 'Remote Europe Jobs',
    description: 'Find remote work and work-from-home jobs in Europe. Apply online for IT, design, marketing, and customer support roles.',
    openLabel: 'Find Remote Jobs ↗',
  },
  {
    title: 'We Work Remotely — Europe',
    dataTitle: 'we work remotely europe online jobs apply',
    url: 'https://weworkremotely.com/categories/remote-jobs-in-europe',
    image: 'https://images.unsplash.com/photo-1542744173-8e7e53415bb0?q=80&w=800&auto=format&fit=crop',
    alt: 'We Work Remotely Europe Jobs',
    artLabel: 'Remote Europe Jobs',
    description: 'Browse remote job listings specifically for Europe-based positions. Apply online from anywhere in the world.',
    openLabel: 'Browse Remote Jobs ↗',
  },
  {
    title: 'Glassdoor Europe Jobs',
    dataTitle: 'glassdoor europe jobs salary reviews',
    url: 'https://www.glassdoor.com/Job/jobs-in-Europe.htm',
    image: 'https://images.unsplash.com/photo-1556761175-5979dc0f32e7?q=80&w=800&auto=format&fit=crop',
    alt: 'Glassdoor Europe Jobs and Salaries',
    artLabel: 'Glassdoor Europe Jobs',
    description: 'Search Europe jobs with salary estimates, company reviews, and interview insights on Glassdoor.',
    openLabel: 'Search Glassdoor ↗',
  },
  {
    title: 'StepStone Europe Jobs',
    dataTitle: 'stepstone europe germany jobs apply online',
    url: 'https://www.stepstone.de/en/',
    image: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?q=80&w=800&auto=format&fit=crop',
    alt: 'StepStone Europe Job Portal',
    artLabel: 'StepStone Jobs',
    description: 'One of Europe\'s largest job portals — search and apply for jobs in Germany, UK, Belgium, and across Europe.',
    openLabel: 'Search StepStone ↗',
  },
  {
    title: 'XING Jobs Germany',
    dataTitle: 'xing jobs germany professional network apply',
    url: 'https://www.xing.com/en/jobs',
    image: 'https://images.unsplash.com/photo-1551434678-e076c223a692?q=80&w=800&auto=format&fit=crop',
    alt: 'XING Jobs Germany Professional Network',
    artLabel: 'XING Germany Jobs',
    description: 'Germany\'s leading professional network for job search. Find jobs, connect with employers, and apply online.',
    openLabel: 'Search XING Jobs ↗',
  },
];

export const visaPortals: VisaCountry[] = [
  { country: 'Germany', flag: '🇩🇪', links: [
    { label: 'Visa application', url: 'https://digital.diplo.de/visa' },
    { label: 'Work visa', url: 'https://pakistan.diplo.de/pk-en/service/4-work-jobseeker-1676106' },
    { label: 'Visit visa', url: 'https://pakistan.diplo.de/pk-en/service/visa-shortterm/1673126' },
    { label: 'Embassy in Pakistan', url: 'https://pakistan.diplo.de/' },
    { label: 'Visa centre', url: 'https://visa.vfsglobal.com/pak/en/deu/' },
  ]},
  { country: 'Poland', flag: '🇵🇱', links: [
    { label: 'Official appointment portal', url: 'https://secure.e-konsulat.gov.pl/' },
    { label: 'Visa information', url: 'https://www.gov.pl/web/pakistan-en/visas---general-information' },
    { label: 'Embassy in Pakistan', url: 'https://www.gov.pl/web/pakistan-en' },
  ]},
  { country: 'France', flag: '🇫🇷', links: [
    { label: 'Visa application', url: 'https://france-visas.gouv.fr/en/' },
    { label: 'France visa Pakistan', url: 'https://www.france-visas.gouv.fr/en/web/france-visas/pakistan' },
    { label: 'Embassy in Pakistan', url: 'https://pk.ambafrance.org/' },
  ]},
  { country: 'Italy', flag: '🇮🇹', links: [
    { label: 'Visa information', url: 'https://vistoperitalia.esteri.it/' },
    { label: 'Foreign affairs', url: 'https://www.esteri.it/en/' },
    { label: 'Embassy in Pakistan', url: 'https://ambislamabad.esteri.it/' },
  ]},
  { country: 'Greece', flag: '🇬🇷', links: [
    { label: 'Visa information', url: 'https://www.mfa.gr/en/visas/' },
    { label: 'Visa centre Pakistan', url: 'https://pk-gr.gvcworld.eu/en' },
    { label: 'Appointment', url: 'https://pk-gr.gvcworld.eu/en/schedule-appointment' },
    { label: 'Embassy information', url: 'https://www.mfa.gr/missionsabroad/en/pakistan-en/' },
  ]},
  { country: 'Spain', flag: '🇪🇸', links: [
    { label: 'Visa information', url: 'https://www.exteriores.gob.es/en/' },
    { label: 'Consular information Pakistan', url: 'https://www.exteriores.gob.es/Consulados/islamabad/en/Paginas/index.aspx' },
    { label: 'Visa centre', url: 'https://pak.blsspainvisa.com/' },
  ]},
  { country: 'Austria', flag: '🇦🇹', links: [
    { label: 'Visa information', url: 'https://www.bmeia.gv.at/en/entry-and-residence/visa' },
    { label: 'Embassy Pakistan', url: 'https://www.bmeia.gv.at/en/austrian-embassy-islamabad' },
    { label: 'Visa centre', url: 'https://visa.vfsglobal.com/pak/en/aut/' },
  ]},
  { country: 'Belgium', flag: '🇧🇪', links: [
    { label: 'Visa information', url: 'https://diplomatie.belgium.be/en' },
    { label: 'Embassy Pakistan', url: 'https://pakistan.diplomatie.belgium.be/en' },
    { label: 'Work permit visa', url: 'https://pakistan.diplomatie.belgium.be/en/travel-belgium/visa-belgium-and-grand-duchy-luxembourg/visa-basis-work-permit' },
  ]},
  { country: 'Netherlands', flag: '🇳🇱', links: [
    { label: 'Visa information', url: 'https://www.netherlandsworldwide.nl/visa-the-netherlands' },
    { label: 'Immigration authority', url: 'https://ind.nl/en' },
    { label: 'Embassy Pakistan', url: 'https://www.netherlandsandyou.nl/' },
  ]},
  { country: 'Portugal', flag: '🇵🇹', links: [
    { label: 'Visa information', url: 'https://vistos.mne.gov.pt/en/' },
    { label: 'Foreign affairs', url: 'https://www.portugal.gov.pt/en/gc25/ministries/foreign-affairs' },
    { label: 'Embassy Pakistan', url: 'https://islamabad.embaixadaportugal.mne.gov.pt/' },
  ]},
  { country: 'Switzerland', flag: '🇨🇭', links: [
    { label: 'Entry and visa information', url: 'https://www.sem.admin.ch/sem/en/home/themen/einreise.html' },
    { label: 'Embassy Pakistan', url: 'https://www.eda.admin.ch/islamabad' },
    { label: 'Visa information Pakistan', url: 'https://www.eda.admin.ch/countries/pakistan/en/home/visa.html' },
  ]},
  { country: 'Sweden', flag: '🇸🇪', links: [
    { label: 'Visa information', url: 'https://www.swedenabroad.se/en/' },
    { label: 'Work permits', url: 'https://www.migrationsverket.se/English.html' },
    { label: 'Embassy Pakistan', url: 'https://www.swedenabroad.se/en/embassies/pakistan-islamabad/' },
  ]},
  { country: 'Finland', flag: '🇫🇮', links: [
    { label: 'Immigration', url: 'https://migri.fi/en/home' },
    { label: 'Visa to visit Finland', url: 'https://um.fi/visa-to-visit-finland' },
    { label: 'Residence permits', url: 'https://enterfinland.fi/eServices' },
    { label: 'Embassy information', url: 'https://finlandabroad.fi/web/pak/current-affairs' },
  ]},
  { country: 'Denmark', flag: '🇩🇰', links: [
    { label: 'Visa information', url: 'https://um.dk/en/travel-and-residence' },
    { label: 'Work and residence', url: 'https://www.nyidanmark.dk/en-GB' },
    { label: 'Embassy Pakistan', url: 'https://pakistan.um.dk/en' },
  ]},
  { country: 'Norway', flag: '🇳🇴', links: [
    { label: 'Visa and immigration', url: 'https://www.udi.no/en/' },
    { label: 'Application portal', url: 'https://my.udi.no/' },
    { label: 'Embassy information', url: 'https://www.norway.no/en/pakistan/' },
  ]},
  { country: 'Ireland', flag: '🇮🇪', links: [
    { label: 'Visa information', url: 'https://www.irishimmigration.ie/' },
    { label: 'Visa application', url: 'https://www.visas.inis.gov.ie/AVATS/OnlineHome.aspx' },
    { label: 'Work permits', url: 'https://enterprise.gov.ie/en/what-we-do/workplace-and-skills/employment-permits/' },
    { label: 'Embassy information', url: 'https://www.ireland.ie/en/pakistan/islamabad/' },
  ]},
  { country: 'United Kingdom', flag: '🇬🇧', links: [
    { label: 'Visa and immigration', url: 'https://www.gov.uk/browse/visas-immigration' },
    { label: 'Apply for a visa', url: 'https://www.gov.uk/apply-to-come-to-the-uk' },
    { label: 'Skilled Worker visa', url: 'https://www.gov.uk/skilled-worker-visa' },
    { label: 'Student visa', url: 'https://www.gov.uk/student-visa' },
    { label: 'Visit visa', url: 'https://www.gov.uk/standard-visitor' },
    { label: 'British High Commission Pakistan', url: 'https://www.gov.uk/world/organisations/british-high-commission-islamabad' },
  ]},
  { country: 'Czechia', flag: '🇨🇿', links: [
    { label: 'Visa information', url: 'https://mzv.gov.cz/jnp/en/information_for_aliens/index.html' },
    { label: 'Embassy Pakistan', url: 'https://mzv.gov.cz/islamabad/en/index.html' },
    { label: 'Immigration information', url: 'https://ipc.gov.cz/en/' },
  ]},
  { country: 'Hungary', flag: '🇭🇺', links: [
    { label: 'Immigration authority', url: 'https://oif.gov.hu/' },
    { label: 'Visa information', url: 'https://konzinfo.mfa.gov.hu/en' },
    { label: 'Embassy Pakistan', url: 'https://islamabad.mfa.gov.hu/eng' },
  ]},
  { country: 'Croatia', flag: '🇭🇷', links: [
    { label: 'Work and residence', url: 'https://mup.gov.hr/aliens-281621/stay-and-work/281622' },
    { label: 'Visa requirements', url: 'https://mvep.gov.hr/consular-information-147214/visa-requirements-overview/22830' },
    { label: 'Foreign affairs', url: 'https://mvep.gov.hr/' },
  ]},
  { country: 'Romania', flag: '🇷🇴', links: [
    { label: 'Official e-Visa application', url: 'https://eviza.mae.ro/' },
    { label: 'Foreign affairs', url: 'https://www.mae.ro/en' },
    { label: 'Immigration authority', url: 'https://igi.mai.gov.ro/en/' },
  ]},
  { country: 'Latvia', flag: '🇱🇻', links: [
    { label: 'Immigration and residence', url: 'https://www.pmlp.gov.lv/en' },
    { label: 'Foreign affairs', url: 'https://www.mfa.gov.lv/en' },
    { label: 'Embassies and consulates', url: 'https://www.mfa.gov.lv/en/embassies-consulates' },
  ]},
  { country: 'Lithuania', flag: '🇱🇹', links: [
    { label: 'Migration information', url: 'https://www.migracija.lt/' },
    { label: 'Foreign affairs', url: 'https://www.urm.lt/en' },
    { label: 'Embassies and consulates', url: 'https://www.urm.lt/en/about-us/embassies-and-consulates' },
  ]},
  { country: 'Luxembourg', flag: '🇱🇺', links: [
    { label: 'Immigration information', url: 'https://guichet.public.lu/en/citoyens/immigration.html' },
    { label: 'Visa information', url: 'https://mae.gouvernement.lu/en.html' },
    { label: 'Embassy information', url: 'https://mae.gouvernement.lu/en/annuaire.html' },
    { label: 'Government portal', url: 'https://guichet.public.lu/en.html' },
  ]},
  { country: 'Malta', flag: '🇲🇹', links: [
    { label: 'Immigration and residence', url: 'https://identita.gov.mt/' },
    { label: 'Work permits', url: 'https://jobsplus.gov.mt/' },
    { label: 'Visa information', url: 'https://identita.gov.mt/central-visa-unit/' },
  ]},
  { country: 'Slovakia', flag: '🇸🇰', links: [
    { label: 'Visa information', url: 'https://www.mzv.sk/web/en/consular_info/visa' },
    { label: 'Foreign affairs', url: 'https://www.mzv.sk/web/en' },
    { label: 'Embassy Islamabad', url: 'https://www.mzv.sk/web/islamabad-en' },
  ]},
  { country: 'Slovenia', flag: '🇸🇮', links: [
    { label: 'Entry and residence', url: 'https://www.gov.si/en/topics/entry-and-residence/' },
    { label: 'Visa information', url: 'https://www.gov.si/en/topics/entry-and-residence/visas/' },
    { label: 'Embassy information', url: 'https://www.gov.si/en/representations/' },
  ]},
  { country: 'Bulgaria', flag: '🇧🇬', links: [
    { label: 'Visa information', url: 'https://www.mfa.bg/en/services-travel/consular-services/travel-bulgaria/visa-bulgaria' },
    { label: 'Foreign affairs', url: 'https://www.mfa.bg/en' },
    { label: 'Embassy directory', url: 'https://www.mfa.bg/en/embassies' },
  ]},
  { country: 'Cyprus', flag: '🇨🇾', links: [
    { label: 'Foreign affairs', url: 'https://mfa.gov.cy/' },
    { label: 'Visa information', url: 'https://mfa.gov.cy/visa-information.html' },
    { label: 'Civil Registry and Migration', url: 'https://www.moi.gov.cy/moi/crmd/crmd.nsf/index_en/index_en' },
  ]},
  { country: 'Estonia', flag: '🇪🇪', links: [
    { label: 'Police and Border Guard', url: 'https://www.politsei.ee/en' },
    { label: 'Foreign affairs', url: 'https://vm.ee/en' },
    { label: 'Visa information', url: 'https://vm.ee/en/consular-visa-and-travel-information' },
  ]},
  { country: 'Iceland', flag: '🇮🇸', links: [
    { label: 'Immigration', url: 'https://island.is/en/o/directorate-of-immigration' },
    { label: 'Visa information', url: 'https://island.is/en/get-a-visa' },
    { label: 'Foreign affairs', url: 'https://www.government.is/ministries/ministry-for-foreign-affairs/' },
  ]},
  { country: 'Liechtenstein', flag: '🇱🇮', links: [
    { label: 'Government portal', url: 'https://www.llv.li/en' },
    { label: 'Immigration information', url: 'https://www.llv.li/en/national-administration/office-for-foreign-affairs' },
  ]},
  { country: 'Serbia', flag: '🇷🇸', links: [
    { label: 'Foreign affairs', url: 'https://www.mfa.gov.rs/en' },
    { label: 'Visa information', url: 'https://welcometoserbia.gov.rs/' },
    { label: 'Electronic visa information', url: 'https://evisa.welcometoserbia.gov.rs/' },
  ]},
  { country: 'Albania', flag: '🇦🇱', links: [
    { label: 'Official visa portal', url: 'https://e-visa.al/' },
    { label: 'Foreign affairs', url: 'https://punetejashtme.gov.al/en/' },
  ]},
  { country: 'Montenegro', flag: '🇲🇪', links: [
    { label: 'Foreign affairs', url: 'https://www.gov.me/en/mvp' },
    { label: 'Visa information', url: 'https://www.gov.me/en/mvp/visas' },
  ]},
  { country: 'North Macedonia', flag: '🇲🇰', links: [
    { label: 'Foreign affairs', url: 'https://mfa.gov.mk/en' },
    { label: 'Visa information', url: 'https://mfa.gov.mk/en/page/12/visa' },
  ]},
  { country: 'Bosnia and Herzegovina', flag: '🇧🇦', links: [
    { label: 'Foreign affairs', url: 'https://www.mvp.gov.ba/' },
    { label: 'Visa information', url: 'https://www.mvp.gov.ba/konzularne_informacije/vize/default.aspx' },
  ]},
  { country: 'Kosovo', flag: '🇽🇰', links: [
    { label: 'Foreign affairs', url: 'https://mfa-ks.net/en/' },
    { label: 'Visa regime', url: 'https://mfa-ks.net/en/visa-regime/' },
  ]},
  { country: 'Moldova', flag: '🇲🇩', links: [
    { label: 'e-Visa portal', url: 'https://evisa.gov.md/' },
    { label: 'Foreign affairs', url: 'https://mfa.gov.md/en' },
  ]},
  { country: 'Ukraine', flag: '🇺🇦', links: [
    { label: 'Foreign affairs', url: 'https://mfa.gov.ua/en' },
    { label: 'e-Visa information', url: 'https://evisa.mfa.gov.ua/' },
  ]},
  { country: 'Turkey', flag: '🇹🇷', links: [
    { label: 'e-Visa portal', url: 'https://www.evisa.gov.tr/' },
    { label: 'Foreign affairs', url: 'https://www.mfa.gov.tr/' },
    { label: 'Visa information', url: 'https://www.mfa.gov.tr/visa-information-for-foreigners.en.mfa' },
  ]},
  { country: 'Andorra', flag: '🇦🇩', links: [
    { label: 'Government portal', url: 'https://www.govern.ad/' },
    { label: 'Immigration information', url: 'https://www.exteriors.ad/' },
  ]},
  { country: 'San Marino', flag: '🇸🇲', links: [
    { label: 'Government portal', url: 'https://www.gov.sm/' },
  ]},
  { country: 'Vatican City', flag: '🇻🇦', links: [
    { label: 'Official website', url: 'https://www.vaticanstate.va/' },
  ]},
  { country: 'Monaco', flag: '🇲🇨', links: [
    { label: 'Government portal', url: 'https://en.gouv.mc/' },
    { label: 'Residence information', url: 'https://en.service-public-entreprises.gouv.mc/' },
  ]},
  { country: 'Canada', flag: '🇨🇦', links: [
    { label: 'Immigration, Refugees and Citizenship Canada', url: 'https://www.canada.ca/en/immigration-refugees-citizenship.html' },
  ]},
  { country: 'Australia', flag: '🇦🇺', links: [
    { label: 'Australian Department of Home Affairs', url: 'https://immi.homeaffairs.gov.au/' },
  ]},
  { country: 'New Zealand', flag: '🇳🇿', links: [
    { label: 'Immigration New Zealand', url: 'https://www.immigration.govt.nz/' },
  ]},
  { country: 'United States', flag: '🇺🇸', links: [
    { label: 'US Department of State Visas', url: 'https://travel.state.gov/content/travel/en/us-visas.html' },
  ]},
  { country: 'Japan', flag: '🇯🇵', links: [
    { label: 'Immigration Services Agency of Japan', url: 'https://www.moj.go.jp/isa/?hl=en' },
  ]},
  { country: 'South Korea', flag: '🇰🇷', links: [
    { label: 'Korea Immigration Service', url: 'https://www.immigration.go.kr/immigration_eng/index.do' },
  ]},
  { country: 'Singapore', flag: '🇸🇬', links: [
    { label: 'Ministry of Manpower: Passes and Permits', url: 'https://www.mom.gov.sg/passes-and-permits' },
  ]},
];

export const europeanJobPortals: NamedLink[] = [
  { name: 'EURES European Jobs', url: 'https://eures.europa.eu/' },
  { name: 'Make it in Germany Jobs', url: 'https://www.make-it-in-germany.com/en/working-in-germany/job-listings' },
  { name: 'Canada Job Bank', url: 'https://www.jobbank.gc.ca/' },
  { name: 'Workforce Australia', url: 'https://www.workforceaustralia.gov.au/' },
  { name: 'Find a Job UK', url: 'https://findajob.dwp.gov.uk/' },
  { name: 'USAJOBS', url: 'https://www.usajobs.gov/' },
  { name: 'International Labour Organization', url: 'https://www.ilo.org/' },
  { name: 'UN Careers', url: 'https://careers.un.org/' },
  { name: 'EURAXESS Research Jobs', url: 'https://euraxess.ec.europa.eu/jobs' },
  { name: 'LinkedIn Jobs Europe', url: 'https://www.linkedin.com/jobs/search/?location=Europe' },
  { name: 'StepStone Germany Jobs', url: 'https://www.stepstone.de/en/' },
  { name: 'Glassdoor Jobs Worldwide', url: 'https://www.glassdoor.com/Job/index.htm' },
  { name: 'EuroEngineerJobs', url: 'https://www.euroengineerjobs.com/' },
  { name: 'TechJobsEurope', url: 'https://www.techjobs.io/europe' },
  { name: 'Jobs.ie Ireland', url: 'https://www.jobs.ie/' },
  { name: 'StepStone UK', url: 'https://www.stepstone.co.uk/' },
  { name: 'Totaljobs UK', url: 'https://www.totaljobs.com/' },
  { name: 'Reed UK Jobs', url: 'https://www.reed.co.uk/' },
  { name: 'Monster Jobs Worldwide', url: 'https://www.monster.com/' },
  { name: 'Gulp.de IT Jobs Germany', url: 'https://www.gulp.de/en' },
  { name: 'XING Jobs Germany', url: 'https://www.xing.com/en/jobs' },
  { name: 'Jobindex Denmark', url: 'https://www.jobindex.dk/' },
  { name: 'StepStone Belgium', url: 'https://www.stepstone.be/' },
  { name: 'InfoJobs Spain', url: 'https://www.infojobs.net/' },
  { name: 'Talent Spain Jobs', url: 'https://www.talent.com/jobs?country=spain' },
  { name: 'Adecco Jobs Worldwide', url: 'https://www.adecco.com/job-search/' },
  { name: 'Michael Page Jobs Europe', url: 'https://www.michaelpage.com/' },
  { name: 'Hays Recruitment Europe', url: 'https://www.hays.com/' },
  { name: 'Randstad Jobs Europe', url: 'https://www.randstad.com/' },
];

export const scholarshipGrid: NamedLink[] = [
  { name: 'Study in Europe', url: 'https://education.ec.europa.eu/study-in-europe' },
  { name: 'Erasmus+ Scholarships', url: 'https://erasmus-plus.ec.europa.eu/' },
  { name: 'Erasmus Mundus Masters Catalogue', url: 'https://www.eacea.ec.europa.eu/scholarships/erasmus-mundus-catalogue_en' },
  { name: 'EURAXESS Research Opportunities', url: 'https://euraxess.ec.europa.eu/' },
  { name: 'European Education Area', url: 'https://education.ec.europa.eu/' },
  { name: 'DAAD Germany Scholarships', url: 'https://www.daad.de/en/' },
  { name: 'Chevening Scholarships', url: 'https://www.chevening.org/' },
  { name: 'USEFP Fulbright Programs', url: 'https://www.usefp.org/' },
  { name: 'EducationUSA', url: 'https://educationusa.state.gov/' },
  { name: 'Australia Awards', url: 'https://www.dfat.gov.au/people-to-people/australia-awards' },
  { name: 'Study in Japan: MEXT', url: 'https://www.studyinjapan.go.jp/en/' },
  { name: 'Study in Korea', url: 'https://www.studyinkorea.go.kr/' },
  { name: 'Commonwealth Scholarships', url: 'https://cscuk.fcdo.gov.uk/' },
];

export const qualificationGrid: NamedLink[] = [
  { name: 'Europass: European CV and Skills Profile', url: 'https://europass.europa.eu/en' },
  { name: 'ENIC-NARIC Qualification Recognition', url: 'https://www.enic-naric.net/' },
  { name: 'EU Regulated Professions Database', url: 'https://ec.europa.eu/growth/tools-databases/regprof/' },
  { name: 'Pakistan Higher Education Commission', url: 'https://www.hec.gov.pk/' },
  { name: 'Pakistan Ministry of Foreign Affairs Attestation', url: 'https://mofa.gov.pk/' },
  { name: 'UK ENIC Qualification Comparison', url: 'https://www.enic.org.uk/' },
  { name: 'Australia Qualification Recognition', url: 'https://internationaleducation.gov.au/services-and-resources/Pages/qualifications-recognition.aspx' },
];

export const visaRequirementGrid: NamedLink[] = [
  { name: 'EU Immigration Portal', url: 'https://home-affairs.ec.europa.eu/policies/migration-and-asylum/eu-immigration-portal_en' },
  { name: 'Canada Immigration Fraud and Protection Guidance', url: 'https://www.canada.ca/en/immigration-refugees-citizenship/services/protect-fraud.html' },
  { name: 'Australian Visa Scam Information', url: 'https://immi.homeaffairs.gov.au/help-support/visa-scams' },
  { name: 'UK Report Immigration Crime', url: 'https://www.gov.uk/report-immigration-crime' },
];

export const scamProtectionGrid: NamedLink[] = [
  { name: 'EURES: Spot Fraudulent Job Offers', url: 'https://eures.europa.eu/how-spot-fraudulent-job-offers-and-misinformation-2023-06-15_en' },
  { name: 'EU Delegation Pakistan: Travel and Study Guidance', url: 'https://www.eeas.europa.eu/pakistan/travel-study_en' },
  { name: 'Canada: Protect Yourself from Immigration Fraud', url: 'https://www.canada.ca/en/immigration-refugees-citizenship/services/protect-fraud.html' },
  { name: 'Australia: Visa Scams', url: 'https://immi.homeaffairs.gov.au/help-support/visa-scams' },
  { name: 'UK: Report Immigration Crime', url: 'https://www.gov.uk/report-immigration-crime' },
];

export const internationalCareersGrid: NamedLink[] = [
  { name: 'UNICEF Careers', url: 'https://jobs.unicef.org/' },
  { name: 'World Health Organization Careers', url: 'https://www.who.int/careers' },
  { name: 'World Bank Careers', url: 'https://www.worldbank.org/en/about/careers' },
  { name: 'International Organization for Migration Careers', url: 'https://www.iom.int/careers' },
];

export const travelSystemGrid: NamedLink[] = [
  { name: 'Entry/Exit System (EES)', url: 'https://travel-europe.europa.eu/ees' },
  { name: 'ETIAS Travel Authorisation', url: 'https://travel-europe.europa.eu/etias' },
];

export const remoteJobsGrid: NamedLink[] = [
  { name: 'Remote OK Europe Jobs', url: 'https://remoteok.com/remote-europe-jobs' },
  { name: 'We Work Remotely — Europe', url: 'https://weworkremotely.com/categories/remote-jobs-in-europe' },
  { name: 'FlexJobs Remote Europe', url: 'https://www.flexjobs.com/locations/remote/europe' },
  { name: 'Remotive Europe Remote Jobs', url: 'https://remotive.com/' },
  { name: 'Working Nomads Europe Jobs', url: 'https://www.workingnomads.com/jobs' },
  { name: 'Jobspresso Remote Europe', url: 'https://jobspresso.co/' },
  { name: 'Remote.co Europe Jobs', url: 'https://remote.co/' },
  { name: 'Europe Remote Jobs', url: 'https://europefy.com/remote-jobs-europe/' },
];

export const socials: NamedLink[] = [
  { name: 'Google', url: 'https://www.google.com/search?q=hassan+jatoi+poetry' },
  { name: 'UrduPoint', url: 'https://www.urdupoint.com/poetry/user-poet/hassan-jatoi-27314.html' },
  { name: 'HelloPoetry', url: 'https://hellopoetry.com/Hassanjatoi/' },
  { name: 'LinkedIn', url: 'https://www.linkedin.com/' },
  { name: 'Fiverr', url: 'https://www.fiverr.com/' },
];

export interface PoetryBook {
  title: string;
  url: string;
  preview: string;
}

export const poetryBooks: PoetryBook[] = [
  {
    title: 'Tears In Eyes (Silent People)',
    url: 'https://hassanaliuk11-oss.github.io/silent-people/',
    preview: 'In the depth of quiet nights, voices remain unspoken. \u2018Tears In Eyes\u2019 explores the hidden emotions of humanity, capturing silent grief, resilient hope, and eternal reflection.',
  },
  {
    title: 'Death of Spirits',
    url: 'https://hassanaliuk11-oss.github.io/the-death-of-soul/',
    preview: 'A philosophical journey into the fading souls and the search for light. \u2018Death of Spirits\u2019 touches upon spiritual awakening and emotional endurance in difficult times.',
  },
  {
    title: 'Lonely Path',
    url: 'https://hassanaliuk11-oss.github.io/The-Lonely-Path/',
    preview: 'Walking through solitary corridors of time, \u2018Lonely Path\u2019 offers deep verses on self-discovery, independence, and the beauty found in solitude.',
  },
];

export const skillBadges: { label: string; color: string }[] = [
  { label: 'Poet & Author', color: 'sky' },
  { label: 'CV Resume Writer', color: 'pink' },
  { label: 'Cover Letter Specialist', color: 'purple' },
  { label: 'Europass Resume Expert', color: 'blue' },
  { label: 'Experience Certificate Maker', color: 'emerald' },
  { label: 'Website Designer', color: 'cyan' },
  { label: 'Graphics Designer', color: 'amber' },
  { label: 'Computer Operator', color: 'teal' },
  { label: 'Software Designer', color: 'indigo' },
  { label: 'Microsoft Engineer & Consultant', color: 'sky' },
  { label: 'FBR Tax NTN File Maker', color: 'rose' },
  { label: 'Revenue Income Tax File Maker', color: 'emerald' },
  { label: 'Computer I.T Specialist', color: 'violet' },
  { label: 'All Types of Tax Work Consultant', color: 'amber' },
];

export const coverImages: string[] = [
  'https://res.cloudinary.com/bppt4zlw/image/upload/f_auto,q_auto/v1791874008/college_admittion.jpg',
  'https://res.cloudinary.com/bppt4zlw/image/upload/v1792166585/WhatsApp_Image_2026-10-16_at_9.01.48_PM.jpg',
  'https://res.cloudinary.com/bppt4zlw/image/upload/v1792166616/WhatsApp_Image_2026-10-16_at_9.01.48_PM_2.jpg',
  'https://res.cloudinary.com/bppt4zlw/image/upload/v1791874072/work_visa_1.webp',
  'https://res.cloudinary.com/bppt4zlw/image/upload/v1792166616/WhatsApp_Image_2026-10-16_at_9.01.48_PM_1.jpg',
];
