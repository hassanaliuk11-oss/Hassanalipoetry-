import { MessageCircle, Send, Zap } from 'lucide-react';
import { useState } from 'react';

export default function CvGenerator() {
  const [name, setName] = useState('');
  const [target, setTarget] = useState('');
  const [service, setService] = useState('Europass Standard CV');

  const handleOrder = () => {
    const msg = `Hello Hassan Jatoi! I would like to order: *${service}*\n\nName: ${name.trim() || 'Client'}\nTarget Country/Role: ${target.trim() || 'General Application'}\n\nPlease guide me on the process.`;
    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/923083500829?text=${encoded}`, '_blank');
  };

  return (
    <section className="reveal active my-12 cv-section">
      <div className="text-center mb-6">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 text-[10px] font-bold tracking-widest uppercase bg-sky-500/15 text-sky-300 rounded-full border border-sky-400/30">
          <Zap className="w-3 h-3" />
          Interactive Technology Tool
        </span>
        <h3 className="text-2xl font-bold text-white mt-3">Europass CV Quick Order Generator</h3>
        <p className="text-xs text-slate-400 mt-1">
          Customize your details below and instantly generate a formatted request to Hassan Jatoi on WhatsApp!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        <div>
          <label className="block text-sky-300 font-bold mb-1.5">Your Full Name</label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="e.g. John Doe"
            className="cv-input"
          />
        </div>
        <div>
          <label className="block text-sky-300 font-bold mb-1.5">Target Country / Role</label>
          <input
            type="text"
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            placeholder="e.g. Germany - Software Engineer"
            className="cv-input"
          />
        </div>
        <div>
          <label className="block text-sky-300 font-bold mb-1.5">Requested Service</label>
          <select
            value={service}
            onChange={(e) => setService(e.target.value)}
            className="cv-input"
          >
            <option>Europass Standard CV</option>
            <option>Professional Cover Letter</option>
            <option>Europass CV + Cover Letter Package</option>
            <option>Experience Certificate & NTN Tax File</option>
          </select>
        </div>
      </div>

      <div className="mt-6 text-center">
        <button
          onClick={handleOrder}
          className="cv-send-btn"
        >
          <MessageCircle className="w-4 h-4" />
          Send Requirements to Hassan Jatoi
        </button>
      </div>
    </section>
  );
}
