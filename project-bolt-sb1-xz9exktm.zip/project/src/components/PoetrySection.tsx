import { useState } from 'react';
import { BookOpen, Volume2, X, ExternalLink } from 'lucide-react';
import { poetryBooks } from '@/data/portals';

export default function PoetrySection() {
  const [modalIndex, setModalIndex] = useState<number | null>(null);
  const [currentModalText, setCurrentModalText] = useState('');

  const openModal = (index: number) => {
    const item = poetryBooks[index];
    setModalIndex(index);
    setCurrentModalText(`${item.title}. ${item.preview}`);
  };

  const closeModal = () => setModalIndex(null);

  const readAloud = () => {
    if (!currentModalText) return;
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const speech = new SpeechSynthesisUtterance(currentModalText);
      speech.rate = 0.9;
      window.speechSynthesis.speak(speech);
    }
  };

  return (
    <section className="reveal active">
      <h2 className="section-title">Poetry Collection Books</h2>
      <div className="grid-books">
        {poetryBooks.map((book, idx) => (
          <div key={book.title} className="glass-card group cursor-pointer">
            <div className="w-12 h-12 rounded-full bg-pink-500/10 border border-pink-400/30 flex items-center justify-center text-pink-400 mb-3 group-hover:scale-110 transition-transform">
              <BookOpen className="w-5 h-5" />
            </div>
            <h4 className="text-lg font-bold text-white group-hover:text-sky-400 transition-colors">{book.title}</h4>
            <button
              onClick={() => openModal(idx)}
              className="mt-4 text-[10px] text-sky-300 font-black uppercase tracking-widest bg-sky-500/10 px-4 py-1.5 rounded-full border border-sky-400/30 shadow-[0_0_10px_rgba(56,189,248,0.2)] hover:bg-sky-500/30 transition-colors"
            >
              Read & Preview Book ↗
            </button>
          </div>
        ))}
      </div>

      {modalIndex !== null && (
        <div className="custom-modal active" onClick={closeModal}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center border-b border-slate-800 pb-3 mb-4">
              <h3 className="text-xl text-sky-300 font-bold">{poetryBooks[modalIndex].title}</h3>
              <button onClick={closeModal} className="text-slate-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>
            <div className="text-slate-300 text-sm space-y-4">
              <p className="italic text-slate-300">{poetryBooks[modalIndex].preview}</p>
            </div>
            <div className="mt-6 pt-4 border-t border-slate-800 flex justify-between items-center">
              <button
                onClick={readAloud}
                className="bg-sky-500/20 text-sky-300 border border-sky-400/30 text-xs px-4 py-2 rounded-full font-bold hover:bg-sky-500/40 transition-colors flex items-center gap-2"
              >
                <Volume2 className="w-4 h-4" />
                Listen Audio
              </button>
              <a
                href={poetryBooks[modalIndex].url}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-pink-500 text-white text-xs px-5 py-2 rounded-full font-bold hover:bg-pink-400 transition-colors flex items-center gap-2"
              >
                Open Full Book Site <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
