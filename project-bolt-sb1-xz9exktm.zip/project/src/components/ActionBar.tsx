import { FileCheck2, Handshake, MessageCircle } from 'lucide-react';

export default function ActionBar() {
  return (
    <nav className="top-action-bar">
      <div className="max-w-[700px] mx-auto flex flex-nowrap justify-center items-center gap-2 sm:gap-3">
        <a
          className="hire-card-top hire-cv"
          href="https://professional-cv-document-center.vercel.app/"
          target="_blank"
          rel="noopener noreferrer"
        >
          <FileCheck2 className="w-4 h-4 shrink-0" />
          <span>Europass CV</span>
        </a>
        <a
          className="hire-card-top hire-fiverr"
          href="https://www.fiverr.com/"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Handshake className="w-4 h-4 shrink-0" />
          <span>Fiverr</span>
        </a>
        <a
          className="hire-card-top hire-wa"
          href="https://wa.me/923083500829"
          target="_blank"
          rel="noopener noreferrer"
        >
          <MessageCircle className="w-4 h-4 shrink-0" />
          <span>WhatsApp</span>
        </a>
      </div>
    </nav>
  );
}
