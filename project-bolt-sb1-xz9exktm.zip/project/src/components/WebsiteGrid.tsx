import { websiteCards } from '@/data/portals';
import { Search } from 'lucide-react';

interface WebsiteGridProps {
  searchQuery: string;
}

export default function WebsiteGrid({ searchQuery }: WebsiteGridProps) {
  const filtered = websiteCards.filter((card) =>
    card.dataTitle.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (filtered.length === 0 && searchQuery.trim()) {
    return (
      <>
        <h2 className="section-title">Global Opportunities & Portals</h2>
        <div className="no-results-card">
          <p className="text-slate-400 text-sm">No matching portals found for "{searchQuery}"</p>
          <a
            href={`https://www.google.com/search?q=${encodeURIComponent(searchQuery.trim() + ' jobs worldwide')}`}
            target="_blank"
            rel="noopener noreferrer"
            className="google-fallback-btn"
          >
            <Search className="w-4 h-4" />
            Search "{searchQuery}" on Google
          </a>
        </div>
      </>
    );
  }

  if (filtered.length === 0) return null;

  return (
    <>
      <h2 className="section-title">Global Opportunities & Portals</h2>
      <div className="website-grid reveal active">
        {filtered.map((card) => (
          <a
            key={card.title}
            className="website-card"
            href={card.url}
            target="_blank"
            rel="noopener noreferrer"
          >
            <div className="website-art">
              <img
                className="website-thumb"
                src={card.image}
                alt={card.alt}
                loading="lazy"
                decoding="async"
              />
              <span className="art-label">{card.artLabel}</span>
            </div>
            <div className="website-copy">
              <h3>{card.title}</h3>
              <p>{card.description}</p>
              <span className="open-label">{card.openLabel}</span>
            </div>
          </a>
        ))}
      </div>
    </>
  );
}
