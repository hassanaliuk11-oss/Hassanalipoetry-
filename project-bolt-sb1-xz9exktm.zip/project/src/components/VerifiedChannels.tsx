import { socials } from '@/data/portals';

interface SocialConfig {
  gradient: string;
  shadow: string;
}

const socialConfig: Record<string, SocialConfig> = {
  Google: {
    gradient: 'from-blue-500 via-red-500 to-amber-500',
    shadow: 'shadow-[0_0_25px_rgba(66,133,244,0.3)]',
  },
  UrduPoint: {
    gradient: 'from-emerald-500 to-green-600',
    shadow: 'shadow-[0_0_25px_rgba(16,185,129,0.3)]',
  },
  HelloPoetry: {
    gradient: 'from-pink-500 to-rose-600',
    shadow: 'shadow-[0_0_25px_rgba(236,72,153,0.3)]',
  },
  LinkedIn: {
    gradient: 'from-blue-600 to-blue-700',
    shadow: 'shadow-[0_0_25px_rgba(0,119,181,0.3)]',
  },
  Fiverr: {
    gradient: 'from-emerald-400 to-green-500',
    shadow: 'shadow-[0_0_25px_rgba(0,191,99,0.3)]',
  },
};

function BrandIcon({ name }: { name: string }) {
  switch (name) {
    case 'Google':
      return (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none">
          <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
          <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
          <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
          <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
        </svg>
      );
    case 'UrduPoint':
      return (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="white">
          <path d="M12 2L3 7v10l9 5 9-5V7l-9-5z" opacity="0.9"/>
          <path d="M12 6.5l-5 2.8v5.4l5 2.8 5-2.8V9.3l-5-2.8z" fill="#10b981"/>
          <text x="12" y="14.5" textAnchor="middle" fontSize="7" fontWeight="bold" fill="white" fontFamily="sans-serif">UP</text>
        </svg>
      );
    case 'HelloPoetry':
      return (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="white">
          <path d="M12 2C8 2 5 5 5 9c0 3 2 5 4 6v5c0 1 1 2 2 2s2-1 2-2v-3c1 0 2-1 2-2s-1-2-2-2c0-2 1-3 3-3 1 0 2-1 2-2s-1-2-2-2c-1 0-2 .5-3 1V4c0-1-1-2-2-2z" opacity="0.95"/>
        </svg>
      );
    case 'LinkedIn':
      return (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="white">
          <path d="M20.5 2h-17A1.5 1.5 0 002 3.5v17A1.5 1.5 0 003.5 22h17a1.5 1.5 0 001.5-1.5v-17A1.5 1.5 0 0020.5 2zM8 19H5v-9h3zM6.5 8.25A1.75 1.75 0 118.3 6.5a1.78 1.78 0 01-1.8 1.75zM19 19h-3v-4.74c0-1.42-.6-1.93-1.38-1.93A1.74 1.74 0 0013 14.19a.66.66 0 000 .14V19h-3v-9h2.9v1.3a3.11 3.11 0 012.7-1.4c1.55 0 3.36.86 3.36 3.66z"/>
        </svg>
      );
    case 'Fiverr':
      return (
        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="white">
          <path d="M23.004 15.588a1 1 0 100-2 1 1 0 000 2zm-11-2.056c.73 0 1.32.6 1.32 1.33s-.59 1.33-1.32 1.33-1.32-.6-1.32-1.33.59-1.33 1.32-1.33zm0-3.29c.73 0 1.32.6 1.32 1.33s-.59 1.33-1.32 1.33-1.32-.6-1.32-1.33.59-1.33 1.32-1.33zm0-3.29c.73 0 1.32.6 1.32 1.33s-.59 1.33-1.32 1.33-1.32-.6-1.32-1.33.59-1.33 1.32-1.33zM5.004 13.588c.73 0 1.32.6 1.32 1.33s-.59 1.33-1.32 1.33-1.32-.6-1.32-1.33.59-1.33 1.32-1.33z" opacity="0.9"/>
          <path d="M14.5 10.5h-2v2h2v-2zm-5 5h3v-3h-3v3zm3 0h2v-2h-2v2zm-6-5h3v-2h-3v2zm0 3h3v-2h-3v2z" fill="#00b22d"/>
        </svg>
      );
    default:
      return null;
  }
}

export default function VerifiedChannels() {
  return (
    <section className="reveal active mt-16">
      <h2 className="section-title">Verified Channels</h2>
      <p className="text-center text-slate-300 text-sm max-w-2xl mx-auto mb-8">
        Follow Hassan Jatoi's published poetry and literary work on these verified platforms.
      </p>
      <div className="grid-social">
        {socials.map((s) => {
          const config = socialConfig[s.name] || socialConfig.Google;
          return (
            <a
              key={s.name}
              href={s.url}
              target="_blank"
              rel="noopener noreferrer"
              className="social-card group"
            >
              <div className={`icon-box group-hover:scale-110 group-hover:rotate-3 ${config.shadow}`}>
                <div className={`w-full h-full rounded-full bg-gradient-to-br ${config.gradient} flex items-center justify-center`}>
                  <BrandIcon name={s.name} />
                </div>
              </div>
              <span className="text-xs font-bold uppercase tracking-widest text-slate-200 group-hover:text-white transition-colors">
                {s.name}
              </span>
              <span className="text-[10px] text-slate-500 group-hover:text-sky-400 transition-colors">
                Visit Profile ↗
              </span>
            </a>
          );
        })}
      </div>
    </section>
  );
}
