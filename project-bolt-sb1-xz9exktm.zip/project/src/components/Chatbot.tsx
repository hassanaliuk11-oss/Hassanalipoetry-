import { useState, useRef, useEffect } from 'react';
import { X, Send, Sparkles } from 'lucide-react';

interface ChatMessage {
  role: 'user' | 'bot';
  text: string;
}

const quickPrompts = [
  'Tell me about Hassan Jatoi',
  'How to get Europass CV?',
  'Work visa for Germany',
  'Scholarships in Italy',
  'Jobs in Europe',
  'Scam protection tips',
  'Poetry books',
  'ETIAS travel info',
];

type KnowledgeEntry = { keywords: string[]; response: string };

const knowledgeBase: KnowledgeEntry[] = [
  {
    keywords: ['hassan jatoi', 'about hassan', 'who is hassan', 'tell me about hassan'],
    response: 'Hassan Jatoi is a Poet, Author, and Digital Architect & Consultant. He specializes in CV writing, Europass resumes, cover letters, experience certificates, website and graphics design, tax filing (FBR/NTN), and IT consulting. He is the author of three poetry books: "Tears In Eyes (Silent People)", "Death of Spirits", and "Lonely Path". You can hire him through Fiverr or WhatsApp at +92 308 3500829.',
  },
  {
    keywords: ['europass', 'cv', 'resume', 'cover letter'],
    response: 'You can order an Europass CV directly from Hassan Jatoi! Use the "Europass CV Quick Order Generator" on this page to customize your details and send a pre-formatted request via WhatsApp. Services include:\n\n• Europass Standard CV\n• Professional Cover Letter\n• CV + Cover Letter Package\n• Experience Certificate & NTN Tax File\n\nAlternatively, visit the Professional CV & Document Center linked in the portal cards above.',
  },
  {
    keywords: ['work visa germany', 'germany visa', 'germany work', 'job seeker germany'],
    response: 'For a German work visa, you need:\n\n1. A job offer from a German employer\n2. Recognition of your qualifications (check via ZAB)\n3. Apply at the German Embassy in Pakistan through VFS Global\n4. Required documents: passport, job contract, qualification proofs, health insurance\n\nOfficial portals:\n• Germany Visa Portal: digital.diplo.de/visa\n• Work visa info: pakistan.diplo.de\n• VFS Global: visa.vfsglobal.com/pak/en/deu/\n\nUse the visa filter buttons above to find Germany under "Work" visa type.',
  },
  {
    keywords: ['work visa', 'work permit', 'employment visa', 'job visa'],
    response: 'Work visas vary by country but generally require:\n\n1. A confirmed job offer or employment contract\n2. Qualification recognition (if applicable)\n3. Valid passport and photographs\n4. Proof of language proficiency (some countries)\n5. Health insurance\n6. Employer sponsorship documents\n\nBrowse the "Visa Applications & Embassy Directory" section above and filter by "Work" to find official portals for 50+ countries including Germany, Poland, France, UK, and more.',
  },
  {
    keywords: ['scholarship italy', 'italy scholarship', 'maeci', 'invest your talent', 'study in italy'],
    response: 'Italy offers several scholarships for international students:\n\n• MAECI Scholarship — Government scholarship for international students (studyinitaly.esteri.it)\n• Invest Your Talent (IYT) — Master\'s programs + industry internship (investyourtalentapplication.esteri.it)\n• Lombardy Regional Scholarships — For students in Milan/Lombardy (unimi.it)\n• DSU Toscana — For students in Tuscany/Pisa/Florence (dsu.toscana.it)\n• DiSCo Lazio — For students in Rome (laziodisco.it)\n• ER.GO — For students in Emilia Romagna/Bologna (er-go.it)\n\nAll are listed in the "Scholarships & University Admissions" section above.',
  },
  {
    keywords: ['scholarship', 'study abroad', 'university', 'education', 'erasmus', 'daad', 'fulbright', 'chevening', 'stipendium'],
    response: 'This directory includes 35+ scholarship portals covering:\n\n• Erasmus Mundus Joint Masters (EU-wide)\n• DAAD Germany Scholarships\n• Chevening UK Scholarships\n• Fulbright US Programs\n• Stipendium Hungaricum (Hungary)\n• Campus France\n• Study in Netherlands\n• Australia Awards\n• MEXT Japan\n• Study in Korea\n• Commonwealth Scholarships\n\nScroll to the "Scholarships & University Admissions" section to explore all options. Always check deadlines on the official portal.',
  },
  {
    keywords: ['jobs europe', 'job in europe', 'european jobs', 'work in europe', 'eures'],
    response: 'Key European job portals:\n\n• EURES — Official EU job mobility portal (eures.europa.eu)\n• Make it in Germany — German job listings\n• Canada Job Bank\n• Workforce Australia\n• Find a Job UK\n• USAJOBS\n• UN Careers\n• EURAXESS — Research jobs\n\nAlso explore the "International Government & Humanitarian Careers" section for UNICEF, WHO, World Bank, and IOM careers. Browse the "International Government Job Portals" section above.',
  },
  {
    keywords: ['visa requirements', 'immigration', 'visa info', 'how to apply visa'],
    response: 'Visa requirements depend on your nationality and travel purpose. Key steps:\n\n1. Identify your visa type (Work, Visit, Student, Family)\n2. Check requirements on the official embassy portal\n3. Gather documents (passport, photos, financial proof, invitation letter, etc.)\n4. Book an appointment at the embassy or visa centre\n5. Submit application and biometrics\n6. Pay visa fee\n\nUse the filter buttons above to search by visa type. The directory covers 50+ European countries plus Canada, USA, Australia, UK, Japan, and more.',
  },
  {
    keywords: ['scam', 'fraud', 'fake visa', 'fake job', 'protection', 'guaranteed visa'],
    response: 'Important scam protection tips:\n\n• Never trust "guaranteed visa" claims — no one can guarantee a visa\n• Verify recruiters and job offers with official authorities\n• Only pay fees through official embassy/visa centre channels\n• Check the EU Delegation Pakistan travel guidance\n• Report immigration crime to official authorities\n• Use the "Scam Protection" section above for official fraud-prevention resources from EU, Canada, Australia, and UK\n\nIf something seems too good to be true, it probably is. Always confirm with official government sources.',
  },
  {
    keywords: ['poetry', 'books', 'poet', 'author', 'tears in eyes', 'death of spirits', 'lonely path'],
    response: 'Hassan Jatoi has published three poetry collections:\n\n1. "Tears In Eyes (Silent People)" — exploring hidden emotions and silent grief.\n2. "Death of Spirits" — a philosophical journey into fading souls and the search for light.\n3. "Lonely Path" — deep verses on self-discovery and the beauty of solitude.\n\nClick "Read & Preview Book" on any book card to read a preview and listen to an audio reading. You can also find his poetry on Google, UrduPoint, and HelloPoetry.',
  },
  {
    keywords: ['etias', 'ees', 'travel europe', 'entry exit system', 'travel authorization'],
    response: 'Europe has two new travel systems:\n\n• EES (Entry/Exit System) — Records entry and exit of non-EU nationals at Schengen borders.\n• ETIAS (European Travel Information and Authorisation System) — Required for visa-exempt travelers to the Schengen Area. It is NOT a visa but a pre-travel authorization.\n\nKey points:\n• ETIAS does not replace a visa where one is required\n• Apply online before travel\n• Check official EU pages for current status\n\nVisit the "Europe Travel Systems" section above for official links.',
  },
  {
    keywords: ['tax', 'fbr', 'ntn', 'income tax', 'tax file'],
    response: 'Hassan Jatoi provides tax-related services:\n\n• FBR Tax NTN File creation\n• Revenue Income Tax File preparation\n• All types of tax work consulting\n\nContact him via WhatsApp at +92 308 3500829 to get started. Mention your requirements and he will guide you through the process.',
  },
  {
    keywords: ['website design', 'graphics', 'it consulting', 'computer', 'software'],
    response: 'Hassan Jatoi offers digital services including:\n\n• Website Design & Development\n• Graphics Design\n• Software Design\n• IT Consulting\n• Computer Operation services\n• Microsoft Engineering & Consulting\n\nContact him on WhatsApp or Fiverr using the buttons at the top of this page to discuss your project.',
  },
  {
    keywords: ['contact', 'whatsapp', 'reach', 'phone', 'email', 'connect'],
    response: 'You can reach Hassan Jatoi through:\n\n• WhatsApp: +92 308 3500829 (click "WhatsApp" button at top)\n• Fiverr: Hire through the Fiverr button at top\n• Europass CV Center: professional-cv-document-center.vercel.app\n\nHe responds to CV orders, visa guidance questions, poetry inquiries, and all digital service requests.',
  },
  {
    keywords: ['france visa', 'france', 'paris'],
    response: 'For France visa applications from Pakistan:\n\n• Official visa portal: france-visas.gouv.fr\n• France visa Pakistan page: france-visas.gouv.fr/en/web/france-visas/pakistan\n• Embassy in Pakistan: pk.ambafrance.org\n\nVisit visa types include tourism, business, family visit. Long-stay visas include student and work visas. Find France in the "Visa Applications & Embassy Directory" section above.',
  },
  {
    keywords: ['uk visa', 'united kingdom', 'britain', 'england', 'skilled worker'],
    response: 'UK visa options include:\n\n• Skilled Worker visa — requires employer sponsorship\n• Student visa — for accepted university students\n• Standard Visitor visa — for tourism/business visits\n\nOfficial portals:\n• gov.uk/browse/visas-immigration\n• Apply at: gov.uk/apply-to-come-to-the-uk\n• British High Commission Pakistan\n\nFind the UK in the "Visa Applications & Embassy Directory" section above.',
  },
  {
    keywords: ['poland visa', 'poland work', 'poland'],
    response: 'For Poland visa applications:\n\n• Official appointment portal: secure.e-konsulat.gov.pl\n• Visa information: gov.pl/web/pakistan-en/visas\n• Embassy in Pakistan: gov.pl/web/pakistan-en\n\nPoland is popular for work visas. You need a work permit from your employer before applying. Find Poland in the "Visa Applications & Embassy Directory" section above.',
  },
  {
    keywords: ['qualification', 'recognition', 'credential', 'enic', 'naric'],
    response: 'Qualification recognition is important for working or studying abroad:\n\n• Europass — Create your European skills profile (europass.europa.eu)\n• ENIC-NARIC — European qualification recognition network\n• ZAB Germany — Central evaluation agency for foreign qualifications\n• UK ENIC — UK qualification comparison\n• Australia qualification recognition\n• Pakistan HEC and MOFA attestation services\n\nSee the "CV, Documents & Qualification Recognition" section above for all official links.',
  },
];

const defaultResponse = 'I can help you with information about:\n\n• Hassan Jatoi\'s services and background\n• Europass CV and cover letter orders\n• Visa guides for 50+ countries (Work, Visit, Student, Family)\n• Scholarships and university admissions\n• Jobs in Europe and international careers\n• Scam protection and fraud prevention\n• ETIAS and EES travel systems\n• Poetry books and literary work\n• Tax filing and IT consulting services\n\nTry asking about any of these topics, or use the quick buttons below!';

function getResponse(msg: string): string {
  const lower = msg.toLowerCase();
  for (const entry of knowledgeBase) {
    if (entry.keywords.some((kw) => lower.includes(kw))) {
      return entry.response;
    }
  }
  return defaultResponse;
}

interface ChatbotProps {
  isOpen: boolean;
  onToggle: () => void;
}

export default function Chatbot({ isOpen, onToggle }: ChatbotProps) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'bot',
      text: "Hello! I am Hassan Jatoi's AI Assistant. I can answer questions about visas, jobs, scholarships, Europass CV services, poetry, and more. How can I help you today?",
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isTyping]);

  const sendMessage = (text: string) => {
    const msg = text.trim();
    if (!msg) return;

    setMessages((prev) => [...prev, { role: 'user', text: msg }]);
    setInput('');
    setIsTyping(true);

    setTimeout(() => {
      const response = getResponse(msg);
      setMessages((prev) => [...prev, { role: 'bot', text: response }]);
      setIsTyping(false);
    }, 700);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  return (
    <>
      {isOpen && (
        <div className="ai-chat-window active">
          <div className="chat-header">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-sky-400 to-pink-500 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div>
                <span className="font-bold text-sm text-white block leading-tight">AI Assistant</span>
                <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  Online now
                </span>
              </div>
            </div>
            <button onClick={onToggle} className="text-slate-400 hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="chat-messages">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={msg.role === 'user' ? 'msg-user' : 'msg-bot'}
                style={{ whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}
              >
                {msg.text}
              </div>
            ))}
            {isTyping && (
              <div className="msg-bot">
                <div className="typing-dots">
                  <span></span><span></span><span></span>
                </div>
              </div>
            )}
            {messages.length <= 1 && !isTyping && (
              <div className="msg-bot" style={{ maxWidth: '90%' }}>
                <p className="text-[11px] text-slate-400 mb-2 mt-1">Quick questions:</p>
                <div className="flex flex-wrap gap-1.5">
                  {quickPrompts.map((prompt) => (
                    <button
                      key={prompt}
                      onClick={() => sendMessage(prompt)}
                      className="text-[10px] bg-sky-500/15 text-sky-300 px-2.5 py-1.5 rounded-lg border border-sky-400/25 hover:bg-sky-500/30 hover:border-sky-400/50 transition-all"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-3 bg-slate-900/80 border-t border-slate-800 flex gap-2">
            <input
              type="text"
              maxLength={2000}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              aria-label="Ask the AI assistant a question"
              placeholder="Ask about visas, jobs, scholarships..."
              className="flex-1 bg-slate-800/80 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-sky-400 transition-colors"
            />
            <button
              type="button"
              aria-label="Send message"
              onClick={() => sendMessage(input)}
              className="bg-gradient-to-br from-sky-500 to-blue-600 text-white px-3 py-2.5 rounded-xl text-xs font-bold hover:opacity-90 transition-opacity flex items-center justify-center"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </>
  );
}
