import { useEffect, useState } from 'react';
import { Check, Search } from 'lucide-react';
import { skillBadges, coverImages } from '@/data/portals';

interface ProfileHeaderProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
}

const badgeColors: Record<string, string> = {
  sky: 'bg-sky-500/10 border-sky-400/40 text-sky-300 shadow-[0_0_10px_rgba(56,189,248,0.15)]',
  pink: 'bg-pink-500/10 border-pink-400/40 text-pink-300 shadow-[0_0_10px_rgba(236,72,153,0.15)]',
  purple: 'bg-purple-500/10 border-purple-400/40 text-purple-300',
  blue: 'bg-blue-500/10 border-blue-400/40 text-blue-300',
  emerald: 'bg-emerald-500/10 border-emerald-400/40 text-emerald-300',
  cyan: 'bg-cyan-500/10 border-cyan-400/40 text-cyan-300',
  amber: 'bg-amber-500/10 border-amber-400/40 text-amber-300',
  teal: 'bg-teal-500/10 border-teal-400/40 text-teal-300',
  indigo: 'bg-indigo-500/10 border-indigo-400/40 text-indigo-300',
  rose: 'bg-rose-500/10 border-rose-400/40 text-rose-300',
  violet: 'bg-violet-500/10 border-violet-400/40 text-violet-300',
};

export default function ProfileHeader({ searchQuery, onSearchChange }: ProfileHeaderProps) {
  const [coverIndex, setCoverIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCoverIndex((prev) => (prev + 1) % coverImages.length);
    }, 6000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="relative w-full max-w-[1200px] mx-auto">
      <div
        className="cover-photo"
        style={{ backgroundImage: `url('${coverImages[coverIndex]}')` }}
      />

      <div className="px-4">
        <div className="profile-pic-wrapper reveal active">
          <div className="profile-pic-ring" />
          <img
            src="https://i.ibb.co/S4ygvhJ3/image.png"
            alt="Hassan Jatoi"
          />
          <div className="verified-badge">
            <Check className="w-4 h-4" />
          </div>
        </div>

        <div className="text-center reveal active">
          <h1 className="colorful-name mt-4">Hassan Jatoi</h1>
          <p className="colorful-subtitle font-bold tracking-[0.3em] text-[12px] md:text-sm mt-2 uppercase">
            Poet & Author • Digital Architect & Consultant
          </p>

          <div className="max-w-4xl mx-auto mt-5 px-2 flex flex-wrap justify-center gap-2">
            {skillBadges.map((badge) => (
              <span
                key={badge.label}
                className={`skill-badge ${badgeColors[badge.color] || badgeColors.sky}`}
              >
                {badge.label}
              </span>
            ))}
          </div>

          <div className="moti-laker" />

          {/* Stats Row */}
          <div className="stats-row max-w-2xl mx-auto mb-6">
            <div className="stat-item">
              <div className="stat-number">50+</div>
              <div className="stat-label">Countries</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">35+</div>
              <div className="stat-label">Portals</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">14</div>
              <div className="stat-label">Services</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">3</div>
              <div className="stat-label">Books</div>
            </div>
          </div>

          <div className="max-w-md mx-auto my-6 px-4">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-sky-400 transition-colors" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder="Search portals, visa guides, books..."
                className="w-full bg-slate-900/90 border border-sky-400/40 rounded-full pl-11 pr-12 py-3 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-pink-500 focus:shadow-[0_0_25px_rgba(56,189,248,0.25)] transition-all duration-300"
              />
              {searchQuery.trim() && (
                <a
                  href={`https://www.google.com/search?q=${encodeURIComponent(searchQuery.trim() + ' jobs worldwide')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="absolute right-1.5 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 via-red-500 to-amber-500 flex items-center justify-center hover:scale-110 transition-transform"
                  title="Search on Google"
                >
                  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="white">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                  </svg>
                </a>
              )}
            </div>

            {/* Quick worldwide job search chips */}
            <div className="mt-3 flex flex-wrap justify-center gap-1.5">
              <span className="text-[10px] text-slate-500 w-full text-center mb-0.5">Quick worldwide job search:</span>
              {['Jobs in Europe', 'Jobs in Germany', 'Jobs in UK', 'Jobs in Canada', 'Jobs in Australia', 'Remote jobs worldwide', 'Government jobs', 'UN jobs'].map((term) => (
                <a
                  key={term}
                  href={`https://www.google.com/search?q=${encodeURIComponent(term)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[10px] bg-slate-800/80 text-sky-300 px-2.5 py-1 rounded-full border border-sky-400/20 hover:bg-sky-500/20 hover:border-sky-400/50 transition-all"
                >
                  {term}
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
