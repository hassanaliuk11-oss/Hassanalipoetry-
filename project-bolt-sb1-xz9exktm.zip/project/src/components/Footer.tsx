import { FileCheck2, Handshake, MessageCircle, Plane, GraduationCap, Briefcase } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="eu-footer">
      <div className="eu-stars" aria-label="European Union stars">✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦ ✦</div>
      <h2 className="eu-footer-title">EUROPE • OPPORTUNITIES • GLOBAL CONNECTIONS</h2>

      {/* Category icons matching header */}
      <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-5 mt-6 mb-8 text-xs font-bold">
        <span className="flex items-center gap-1.5 text-yellow-400">
          <Plane className="w-4 h-4" />
          <span className="text-sky-200 tracking-wide uppercase">Visa Guides</span>
        </span>
        <span className="text-slate-600">•</span>
        <span className="flex items-center gap-1.5 text-pink-400">
          <GraduationCap className="w-4 h-4" />
          <span className="text-sky-200 tracking-wide uppercase">Scholarships</span>
        </span>
        <span className="text-slate-600">•</span>
        <span className="flex items-center gap-1.5 text-emerald-400">
          <Briefcase className="w-4 h-4" />
          <span className="text-sky-200 tracking-wide uppercase">EU Jobs</span>
        </span>
      </div>

      {/* Hire-me buttons matching header action bar */}
      <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-8">
        <a
          className="hire-card-top hire-cv"
          href="https://professional-cv-document-center.vercel.app/"
          target="_blank"
          rel="noopener noreferrer"
        >
          <FileCheck2 className="w-4 h-4 shrink-0" />
          <span>Europass CV</span>
        </a>
        <a
          className="hire-card-top hire-fiverr"
          href="https://www.fiverr.com/"
          target="_blank"
          rel="noopener noreferrer"
        >
          <Handshake className="w-4 h-4 shrink-0" />
          <span>Fiverr</span>
        </a>
        <a
          className="hire-card-top hire-wa"
          href="https://wa.me/923083500829"
          target="_blank"
          rel="noopener noreferrer"
        >
          <MessageCircle className="w-4 h-4 shrink-0" />
          <span>WhatsApp</span>
        </a>
      </div>

      <p className="text-slate-400 text-sm max-w-2xl mx-auto">
        Explore visa information, jobs, scholarships and country resources through the official websites listed above.
      </p>
      <p className="text-slate-500 text-xs max-w-2xl mx-auto mt-3">
        Independent information directory by Hassan Jatoi. Always verify visa, job and scholarship requirements on the relevant official government or university website.
      </p>

      {/* Europass-style bottom strip */}
      <div className="eu-footer-strip">
        <span className="eu-flag">🇪🇺</span>
        <p className="eu-footer-credit">HASSAN JATOI · DIGITAL PORTFOLIO © 2026</p>
        <span className="eu-flag">🇪🇺</span>
      </div>
    </footer>
  );
}
