import { ArrowUp, Bot } from 'lucide-react';

interface BottomDockProps {
  onToggleChat: () => void;
  isChatOpen: boolean;
}

export default function BottomDock({ onToggleChat, isChatOpen }: BottomDockProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="bottom-dock">
      <button onClick={scrollToTop} className="dock-btn" title="Back to Top">
        <ArrowUp className="w-5 h-5" />
        <span>Top</span>
      </button>
      <button onClick={onToggleChat} className={`dock-btn dock-chat ${isChatOpen ? 'dock-chat-active' : ''}`} title="Ask AI Assistant">
        <Bot className="w-5 h-5" />
        <span>{isChatOpen ? 'Close' : 'Chat'}</span>
      </button>
    </div>
  );
}
