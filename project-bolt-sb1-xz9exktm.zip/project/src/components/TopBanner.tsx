import { Plane, GraduationCap, Briefcase } from 'lucide-react';

export default function TopBanner() {
  return (
    <div className="eu-top-header py-3 px-4 text-center">
      <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-2 text-xs md:text-sm font-bold text-sky-200">
        <div className="flex items-center gap-2 mx-auto md:mx-0">
          <span className="text-lg">🇪🇺</span>
          <span className="tracking-widest uppercase">European Union Official Gateway & Opportunities Directory</span>
        </div>
        <div className="hidden md:flex items-center gap-3 text-xs text-sky-300 mx-auto md:mx-0">
          <span className="flex items-center gap-1"><Plane className="w-3 h-3 text-yellow-400" /> Visa Guides</span>
          <span>•</span>
          <span className="flex items-center gap-1"><GraduationCap className="w-3 h-3 text-pink-400" /> Scholarships</span>
          <span>•</span>
          <span className="flex items-center gap-1"><Briefcase className="w-3 h-3 text-emerald-400" /> EU Jobs</span>
        </div>
      </div>
    </div>
  );
}
