import { useMemo, useState } from 'react';
import { visaPortals, europeanJobPortals, scholarshipGrid, qualificationGrid, visaRequirementGrid, scamProtectionGrid, internationalCareersGrid, travelSystemGrid, remoteJobsGrid, type NamedLink, type VisaCountry } from '@/data/portals';

function getVisaType(label: string): string {
  const t = label.toLowerCase();
  if (/work|employment|job|worker|permit/.test(t)) return 'work';
  if (/visit|short.?stay|touris/.test(t)) return 'visit';
  if (/student|study|education/.test(t)) return 'student';
  if (/family|reunion|dependent/.test(t)) return 'family';
  return 'general';
}

function VisaCountryCard({ country }: { country: VisaCountry }) {
  return (
    <article className="website-card">
      <div className="website-copy">
        <h3><span className="visa-flag">{country.flag}</span>{country.country}</h3>
        <div className="portal-link-list">
          {country.links.map((link) => (
            <a
              key={link.url}
              className="portal-link"
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={`${link.label} for ${country.country}, opens in a new tab`}
            >
              {link.label} ↗
            </a>
          ))}
        </div>
        <p className="portal-meta">Directory reviewed 14 Oct 2026; confirm details at source</p>
      </div>
    </article>
  );
}

function NamedLinkCard({ name, url, showDeadline }: { name: string; url: string; showDeadline?: boolean }) {
  return (
    <article className="website-card">
      <div className="website-copy">
        <h3>{name}</h3>
        <div className="portal-link-list">
          <a
            className="portal-link"
            href={url}
            target="_blank"
            rel="noopener noreferrer"
          >
            Open official portal ↗
          </a>
        </div>
        {showDeadline && (
          <p className="portal-meta">Deadline: check current cycle on official portal</p>
        )}
        <p className="portal-meta">Directory reviewed 14 Oct 2026; confirm details at source</p>
      </div>
    </article>
  );
}

function NamedLinkGrid({ items, showDeadline }: { items: NamedLink[]; showDeadline?: boolean }) {
  return (
    <div className="website-grid">
      {items.map((item) => (
        <NamedLinkCard key={item.url} name={item.name} url={item.url} showDeadline={showDeadline} />
      ))}
    </div>
  );
}

const filterButtons = [
  { label: 'All visa links', value: 'all' },
  { label: 'Work', value: 'work' },
  { label: 'Visit', value: 'visit' },
  { label: 'Student', value: 'student' },
  { label: 'Family', value: 'family' },
] as const;

export default function VisaDirectory({ searchQuery }: { searchQuery: string }) {
  const [visaFilter, setVisaFilter] = useState<string>('all');

  const filteredVisaCountries = useMemo(() => {
    const q = searchQuery.toLowerCase();
    return visaPortals
      .map((country) => ({
        ...country,
        links: country.links.filter((link) => {
          const matchesType = visaFilter === 'all' || getVisaType(link.label) === visaFilter;
          const matchesSearch = q === '' || `${country.country} ${link.label} ${link.url}`.toLowerCase().includes(q);
          return matchesType && matchesSearch;
        }),
      }))
      .filter((c) => c.links.length > 0);
  }, [visaFilter, searchQuery]);

  return (
    <section className="reveal active my-12">
      <h2 className="section-title">International Jobs, Visa & Scholarship Directory</h2>
      <p className="text-center text-slate-300 text-sm max-w-3xl mx-auto mb-4">
        Browse official government and institution portals. Visa rules depend on nationality and purpose; confirm requirements on the official site before applying.
      </p>
      <p className="text-center text-xs text-sky-300 mb-6">
        Directory links reviewed: <time dateTime="2026-10-14">14 October 2026</time>. This date indicates the directory update, not a guarantee that every external page is available.
      </p>

      <div className="filter-row flex flex-wrap justify-center gap-2 mb-8" role="group" aria-label="Filter visa links by type">
        {filterButtons.map((btn) => (
          <button
            key={btn.value}
            className="filter-button"
            type="button"
            aria-pressed={visaFilter === btn.value}
            onClick={() => setVisaFilter(btn.value)}
          >
            {btn.label}
          </button>
        ))}
      </div>

      <h2 className="section-title">Visa Applications & Embassy Directory</h2>
      <div className="website-grid">
        {filteredVisaCountries.map((country) => (
          <VisaCountryCard key={country.country} country={country} />
        ))}
      </div>

      <h2 className="section-title">International Government Job Portals</h2>
      <div id="jobs">
        <NamedLinkGrid items={europeanJobPortals} />
      </div>

      <h2 className="section-title">Remote & Online Europe Jobs</h2>
      <div id="remote-jobs">
        <p className="text-center text-slate-300 text-sm max-w-3xl mx-auto">
          Apply for remote and work-from-home jobs in Europe from anywhere in the world. These platforms list online IT, design, marketing, and customer support roles for European employers.
        </p>
        <NamedLinkGrid items={remoteJobsGrid} />
      </div>

      <h2 className="section-title">Scholarships & University Admissions</h2>
      <div id="scholarships">
      <p className="text-center text-slate-300 text-sm max-w-3xl mx-auto">
        Deadlines change by programme and year. Each official portal is labelled "Check current deadline"; verify dates on the linked programme page.
      </p>
      <NamedLinkGrid items={scholarshipGrid} showDeadline />
      </div>

      <h2 className="section-title">CV, Documents & Qualification Recognition</h2>
      <p className="text-center text-slate-300 text-sm max-w-3xl mx-auto">
        Recognition rules vary by profession and destination; qualifications are not automatically accepted everywhere.
      </p>
      <NamedLinkGrid items={qualificationGrid} />

      <h2 className="section-title">Visa Requirements & Immigration</h2>
      <NamedLinkGrid items={visaRequirementGrid} />

      <h2 className="section-title">Scam Protection</h2>
      <p className="text-center text-amber-200 text-sm max-w-3xl mx-auto">
        Do not trust guaranteed-visa claims or suspicious job offers. Confirm fees, recruiters and applications with official authorities.
      </p>
      <NamedLinkGrid items={scamProtectionGrid} />

      <h2 className="section-title">International Government & Humanitarian Careers</h2>
      <NamedLinkGrid items={internationalCareersGrid} />

      <h2 className="section-title">Europe Travel Systems</h2>
      <p className="text-center text-slate-300 text-sm max-w-3xl mx-auto">
        Check official EU pages for current EES and ETIAS status. ETIAS does not replace a visa where one is required.
      </p>
      <NamedLinkGrid items={travelSystemGrid} />
    </section>
  );
}
