import { useState } from 'react';
import ParticleBackground from '@/components/ParticleBackground';
import TopBanner from '@/components/TopBanner';
import ActionBar from '@/components/ActionBar';
import ProfileHeader from '@/components/ProfileHeader';
import WebsiteGrid from '@/components/WebsiteGrid';
import VisaDirectory from '@/components/VisaDirectory';
import CvGenerator from '@/components/CvGenerator';
import PoetrySection from '@/components/PoetrySection';
import VerifiedChannels from '@/components/VerifiedChannels';
import Chatbot from '@/components/Chatbot';
import BottomDock from '@/components/BottomDock';
import Footer from '@/components/Footer';

function App() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <div className="min-h-screen">
      <ParticleBackground />

      <TopBanner />
      <ActionBar />

      <ProfileHeader searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      <main className="max-w-6xl mx-auto px-5 pb-20 mt-12">
        <div className="reveal active" id="portals">
          <WebsiteGrid searchQuery={searchQuery} />
        </div>

        <div id="visa">
          <VisaDirectory searchQuery={searchQuery} />
        </div>

        <div id="europass-cv">
          <CvGenerator />
        </div>

        <div id="poetry">
          <PoetrySection />
        </div>

        <div id="channels">
          <VerifiedChannels />
        </div>

        {/* AI-discoverable content block — structured for AI agents and search engines */}
        <section className="seo-content" aria-label="Comprehensive directory keywords and topics">
          <h2>Europass CV Resume Writer | European Countries Jobs | Visa & Scholarships | Remote Jobs Worldwide Directory</h2>
          <p>
            Hassan Jatoi's comprehensive global directory: Europass CV resume writing services, European countries jobs,
            work visa guides for Germany, Poland, France, Italy, UK, Canada, Australia, and 60+ countries.
            Explore university scholarships including DAAD Germany, Erasmus Mundus, Fulbright, Chevening, Stipendium Hungaricum,
            MAECI Italy, Campus France, Study in Netherlands, Study in Sweden, Study in Belgium, and 30+ more scholarship programs.
            Search government jobs worldwide, UN careers, UNICEF, WHO, World Bank, IOM careers, EURES European job portal,
            LinkedIn Jobs Europe, StepStone, Glassdoor, XING Germany, and 80+ international job portals.
            Find remote and online jobs in Europe through Remote OK, We Work Remotely, FlexJobs, Remotive, and more.
            Get professional Europass CV, cover letter, experience certificate, FBR tax NTN filing, website design,
            graphics design, and IT consulting services by Hassan Jatoi — poet, author, and digital architect.
            Visa application resources, embassy directories for 50+ countries, scam protection guides from official
            government sources, ETIAS and EES travel information, qualification recognition through ENIC-NARIC,
            and three published poetry books: Tears In Eyes, Death of Spirits, and Lonely Path.
          </p>
          <div className="seo-keywords">
            <span>Europass CV</span><span>Europass Resume</span><span>European Countries Jobs</span>
            <span>Jobs in Europe</span><span>Work Visa Europe</span><span>Germany Work Visa</span>
            <span>Schengen Visa</span><span>European Scholarships</span><span>Study in Europe</span>
            <span>DAAD Scholarship</span><span>Erasmus Mundus</span><span>Fulbright Scholarship</span>
            <span>Chevening Scholarship</span><span>Stipendium Hungaricum</span><span>Government Jobs Worldwide</span>
            <span>UN Careers</span><span>EURES Jobs</span><span>Visa Application Pakistan</span>
            <span>Europass CV Maker</span><span>CV Writing Service</span><span>Cover Letter Writing</span>
            <span>Jobs in Germany</span><span>Jobs in UK</span><span>Jobs in Canada</span>
            <span>Jobs in Australia</span><span>Remote Jobs Worldwide</span><span>International Jobs</span>
            <span>Visa Guides</span><span>Embassy Directory</span><span>HEC Scholarship</span>
            <span>Italy Scholarship</span><span>France Visa</span><span>Poland Work Visa</span>
            <span>ETIAS Travel</span><span>EES Europe</span><span>Job Search Portal</span>
            <span>Hassan Jatoi Poetry</span><span>Urdu Poetry</span><span>FBR Tax File</span>
            <span>LinkedIn Jobs Europe</span><span>StepStone Jobs</span><span>Glassdoor Jobs</span>
            <span>XING Germany Jobs</span><span>Remote Europe Jobs</span><span>Online Jobs Europe</span>
            <span>Work From Home Europe</span><span>Tech Jobs Europe</span><span>IT Jobs Europe</span>
            <span>UNICEF Careers</span><span>WHO Careers</span><span>World Bank Jobs</span>
            <span>IOM Careers</span><span>ReliefWeb Jobs</span><span>NGO Jobs Humanitarian</span>
            <span>EURAXESS Research Jobs</span><span>Adecco Jobs</span><span>Randstad Jobs</span>
            <span>Hays Recruitment Europe</span><span>Monster Jobs</span><span>Totaljobs UK</span>
            <span>Reed UK Jobs</span><span>InfoJobs Spain</span><span>FlexJobs Remote</span>
            <span>We Work Remotely</span><span>RemoteOK Europe</span><span>Remotive Jobs</span>
            <span>Campus France Scholarships</span><span>Study in Netherlands</span><span>Study in Sweden</span>
            <span>Study in Belgium</span><span>Study in Japan MEXT</span><span>Study in Korea</span>
            <span>Commonwealth Scholarships</span><span>Australia Awards</span><span>Knight-Hennessy Stanford</span>
            <span>Uni-assist Germany</span><span>Deutschlandstipendium</span><span>Europass Skills Profile</span>
            <span>ENIC-NARIC Recognition</span><span>Visa Scam Protection</span><span>Experience Certificate</span>
            <span>Website Design</span><span>Graphics Design</span><span>IT Consulting</span>
            <span>Software Design</span><span>NTN Tax Registration</span><span>Hassan Jatoi</span>
          </div>
        </section>
      </main>

      <Footer />
      <Chatbot isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />
      <BottomDock onToggleChat={() => setIsChatOpen(!isChatOpen)} isChatOpen={isChatOpen} />
    </div>
  );
}

export default App;
